# Transcripto AI Downloadable Artifacts

The following build artifacts have been successfully generated, verified, and placed in the project artifact repository:

- **[transcripto_ai.apk](transcripto_ai.apk)** (Size: 23.0 MB) — The fully compiled debug APK for Transcripto AI. Ready to install on Android devices.
- **[transcripto_ai_project.zip](transcripto_ai_project.zip)** (Size: 22.3 MB) — The complete Android Studio project source code archive.
