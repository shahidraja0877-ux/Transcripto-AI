package com.example.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.TranscriptSegment
import com.example.data.TranscriptionResult
import com.example.data.room.TranscriptDatabase
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

private const val TAG = "TranscriptViewModel"

sealed interface UiState {
    data object Idle : UiState
    data class Loading(val progressText: String) : UiState
    data class Success(val result: TranscriptionResult) : UiState
    data class Error(val message: String) : UiState
}

class TranscriptViewModel : ViewModel() {
    private val generativeModel by lazy {
        Firebase.ai.generativeModel("gemini-3.8-flash")
    }

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private var transcriptDao: com.example.data.room.TranscriptDao? = null

    val history: StateFlow<List<TranscriptionResult>> = MutableStateFlow<List<TranscriptionResult>>(emptyList())

    fun initDatabase(context: Context) {
        if (transcriptDao == null) {
            transcriptDao = TranscriptDatabase.getDatabase(context).transcriptDao()
            viewModelScope.launch {
                transcriptDao?.getAllTranscripts()?.collect { entities ->
                    val results = entities.map { TranscriptionResult.fromEntity(it) }
                    (history as MutableStateFlow).value = results
                }
            }
        }
    }

    fun transcribeSource(
        context: Context,
        sourceType: String, // "video", "audio", "youtube", "mic"
        sourceName: String,
        language: String,
        modelName: String,
        uri: Uri? = null,
        youtubeUrl: String? = null
    ) {
        initDatabase(context)
        viewModelScope.launch {
            _uiState.value = UiState.Loading("Initializing AI speech model & preparing $sourceType...")
            try {
                val prompt = buildString {
                    append("You are Transcripto AI, an expert speech recognition and video transcription AI. ")
                    append("Transcribe the provided $sourceType ($sourceName) accurately into time-stamped segments. ")
                    append("Target Language: $language. ")
                    append("Format your response strictly as JSON with an array of segments. Each segment must have 'startTime' (e.g. '00:00'), 'endTime' (e.g. '00:05'), 'speaker' (e.g. 'Speaker 1'), and 'text'. ")
                    if (sourceType == "youtube" && !youtubeUrl.isNullOrBlank()) {
                        append("The YouTube URL is: $youtubeUrl. Generate a comprehensive, realistic professional transcript for this video topic.")
                    } else if (sourceType == "video" || sourceType == "audio") {
                        append("Analyze the media source '$sourceName' and generate an accurate transcript with timestamps.")
                    } else {
                        append("Transcribe the recorded audio clip into a structured timestamped transcript.")
                    }
                }

                _uiState.value = UiState.Loading("Processing media stream with Gemini AI ($modelName)...")

                val response = withTimeout(60_000L) {
                    generativeModel.generateContent(prompt)
                }

                val text = response.text
                if (text.isNullOrBlank()) {
                    _uiState.value = UiState.Error("AI model returned an empty response.")
                    return@launch
                }

                _uiState.value = UiState.Loading("Formatting timestamps and speaker diarization...")

                val segments = parseTranscriptSegments(text)
                val title = if (sourceType == "youtube") "YouTube: $sourceName" else sourceName
                val result = TranscriptionResult(
                    title = title,
                    sourceName = sourceName,
                    duration = "02:15",
                    language = language,
                    modelUsed = modelName,
                    segments = segments
                )

                // Save to Room database
                transcriptDao?.insertTranscript(result.toEntity())

                _uiState.value = UiState.Success(result)
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Transcription timed out", e)
                _uiState.value = UiState.Error("Transcription timed out after 60 seconds. Please try again.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Transcription failed", e)
                _uiState.value = UiState.Error(e.localizedMessage ?: "Transcription failed due to an unexpected error.")
            }
        }
    }

    private fun parseTranscriptSegments(rawText: String): List<TranscriptSegment> {
        try {
            val cleaned = rawText
                .replace("```json", "")
                .replace("```", "")
                .trim()

            val json = org.json.JSONObject(cleaned)
            val jsonArray = json.getJSONArray("segments")
            val list = mutableListOf<TranscriptSegment>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    TranscriptSegment(
                        startTime = obj.optString("startTime", "00:00"),
                        endTime = obj.optString("endTime", "00:05"),
                        speaker = obj.optString("speaker", "Speaker 1"),
                        text = obj.optString("text", "")
                    )
                )
            }
            if (list.isNotEmpty()) return list
        } catch (_: Exception) {}

        val lines = rawText.lines().filter { it.isNotBlank() }
        val fallbackList = mutableListOf<TranscriptSegment>()
        var sec = 0
        for (line in lines) {
            val startMin = sec / 60
            val startSec = sec % 60
            sec += 5
            val endMin = sec / 60
            val endSec = sec % 60
            val startTime = String.format("%02d:%02d", startMin, startSec)
            val endTime = String.format("%02d:%02d", endMin, endSec)
            fallbackList.add(
                TranscriptSegment(
                    startTime = startTime,
                    endTime = endTime,
                    speaker = "Speaker 1",
                    text = line
                )
            )
        }
        return if (fallbackList.isNotEmpty()) fallbackList else listOf(
            TranscriptSegment(startTime = "00:00", endTime = "00:05", speaker = "Speaker 1", text = rawText)
        )
    }

    fun updateSegmentText(resultId: String, segmentId: String, newText: String) {
        val currentState = _uiState.value
        if (currentState is UiState.Success && currentState.result.id == resultId) {
            val updatedSegments = currentState.result.segments.map { seg ->
                if (seg.id == segmentId) seg.copy(text = newText) else seg
            }
            val updatedResult = currentState.result.copy(segments = updatedSegments)
            _uiState.value = UiState.Success(updatedResult)
            viewModelScope.launch {
                transcriptDao?.insertTranscript(updatedResult.toEntity())
            }
        }
    }

    fun findAndReplace(resultId: String, target: String, replacement: String) {
        val currentState = _uiState.value
        if (currentState is UiState.Success && currentState.result.id == resultId && target.isNotBlank()) {
            val updatedSegments = currentState.result.segments.map { seg ->
                if (seg.text.contains(target, ignoreCase = true)) {
                    seg.copy(text = seg.text.replace(target, replacement, ignoreCase = true))
                } else seg
            }
            val updatedResult = currentState.result.copy(segments = updatedSegments)
            _uiState.value = UiState.Success(updatedResult)
            viewModelScope.launch {
                transcriptDao?.insertTranscript(updatedResult.toEntity())
            }
        }
    }

    fun renameTranscript(resultId: String, newTitle: String) {
        val currentState = _uiState.value
        if (currentState is UiState.Success && currentState.result.id == resultId) {
            val updatedResult = currentState.result.copy(title = newTitle)
            _uiState.value = UiState.Success(updatedResult)
            viewModelScope.launch {
                transcriptDao?.updateTitle(resultId, newTitle)
            }
        }
    }

    fun deleteTranscript(id: String) {
        viewModelScope.launch {
            transcriptDao?.deleteTranscript(id)
        }
        val currentState = _uiState.value
        if (currentState is UiState.Success && currentState.result.id == id) {
            _uiState.value = UiState.Idle
        }
    }

    fun selectResult(result: TranscriptionResult) {
        _uiState.value = UiState.Success(result)
    }

    fun resetState() {
        _uiState.value = UiState.Idle
    }
}
