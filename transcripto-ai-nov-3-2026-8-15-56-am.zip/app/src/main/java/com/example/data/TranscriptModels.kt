package com.example.data

import com.example.data.room.TranscriptEntity
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class TranscriptSegment(
    val id: String = UUID.randomUUID().toString(),
    val startTime: String, // e.g. "00:00"
    val endTime: String,   // e.g. "00:05"
    val speaker: String,   // e.g. "Speaker 1"
    val text: String
)

data class TranscriptionResult(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val sourceName: String,
    val duration: String,
    val language: String,
    val modelUsed: String,
    val createdAt: Long = System.currentTimeMillis(),
    val segments: List<TranscriptSegment>
) {
    fun toPlainText(): String {
        return segments.joinToString("\n\n") { seg ->
            "[${seg.startTime} - ${seg.endTime}] ${seg.speaker}: ${seg.text}"
        }
    }

    fun toSrt(): String {
        val sb = StringBuilder()
        segments.forEachIndexed { index, seg ->
            sb.append("${index + 1}\n")
            sb.append("00:${seg.startTime},000 --> 00:${seg.endTime},000\n")
            sb.append("${seg.speaker}: ${seg.text}\n\n")
        }
        return sb.toString()
    }

    fun toVtt(): String {
        val sb = StringBuilder()
        sb.append("WEBVTT\n\n")
        segments.forEachIndexed { index, seg ->
            sb.append("${index + 1}\n")
            sb.append("00:${seg.startTime}.000 --> 00:${seg.endTime}.000\n")
            sb.append("${seg.speaker}: ${seg.text}\n\n")
        }
        return sb.toString()
    }

    fun toEntity(): TranscriptEntity {
        val jsonArray = JSONArray()
        for (seg in segments) {
            val obj = JSONObject().apply {
                put("id", seg.id)
                put("startTime", seg.startTime)
                put("endTime", seg.endTime)
                put("speaker", seg.speaker)
                put("text", seg.text)
            }
            jsonArray.put(obj)
        }
        return TranscriptEntity(
            id = id,
            title = title,
            sourceName = sourceName,
            duration = duration,
            language = language,
            modelUsed = modelUsed,
            createdAt = createdAt,
            segmentsJson = jsonArray.toString()
        )
    }

    companion object {
        fun fromEntity(entity: TranscriptEntity): TranscriptionResult {
            val segments = mutableListOf<TranscriptSegment>()
            try {
                val jsonArray = JSONArray(entity.segmentsJson)
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    segments.add(
                        TranscriptSegment(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            startTime = obj.optString("startTime", "00:00"),
                            endTime = obj.optString("endTime", "00:05"),
                            speaker = obj.optString("speaker", "Speaker 1"),
                            text = obj.optString("text", "")
                        )
                    )
                }
            } catch (_: Exception) {}

            return TranscriptionResult(
                id = entity.id,
                title = entity.title,
                sourceName = entity.sourceName,
                duration = entity.duration,
                language = entity.language,
                modelUsed = entity.modelUsed,
                createdAt = entity.createdAt,
                segments = segments
            )
        }
    }
}
