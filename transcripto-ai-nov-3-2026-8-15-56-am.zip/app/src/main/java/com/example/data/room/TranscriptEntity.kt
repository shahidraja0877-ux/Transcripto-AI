package com.example.data.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transcripts")
data class TranscriptEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val sourceName: String,
    val duration: String,
    val language: String,
    val modelUsed: String,
    val createdAt: Long,
    val segmentsJson: String // Serialized segments JSON
)
