package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
      primary = IndigoDarkPrimary,
      secondary = TealAccent,
      background = BackgroundDark,
      surface = SurfaceDark,
      onPrimary = BackgroundDark,
      onSecondary = BackgroundDark,
      onBackground = TextDarkPrimary,
      onSurface = TextDarkPrimary
  )

private val LightColorScheme =
  lightColorScheme(
      primary = IndigoPrimary,
      secondary = TealAccent,
      background = BackgroundLight,
      surface = SurfaceLight,
      onPrimary = SurfaceLight,
      onSecondary = SurfaceLight,
      onBackground = TextPrimary,
      onSurface = TextPrimary
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Set to false to maintain crisp SaaS brand colors
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
