package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.utils.configureAppCheck
import com.example.viewmodel.TranscriptViewModel
import com.example.viewmodel.UiState
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure App Check before UI or ViewModel initialization
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    val viewModel: TranscriptViewModel = viewModel()
                    val uiState by viewModel.uiState.collectAsState()

                    // Initialize Room DB
                    LaunchedEffect(Unit) {
                        viewModel.initDatabase(applicationContext)
                    }

                    // If processing succeeded, navigate to results if not already there
                    LaunchedEffect(uiState) {
                        if (uiState is UiState.Success) {
                            navController.navigate("results") {
                                popUpTo("home") { inclusive = false }
                            }
                        }
                    }

                    NavHost(navController = navController, startDestination = "splash") {
                        composable("splash") {
                            SplashScreen {
                                navController.navigate("home") {
                                    popUpTo("splash") { inclusive = true }
                                }
                            }
                        }
                        composable("home") {
                            HomeScreen(viewModel = viewModel) { route ->
                                navController.navigate(route)
                            }
                        }
                        composable("video_upload") {
                            VideoUploadScreen(
                                viewModel = viewModel,
                                onNavigateNext = { type, name, uri ->
                                    val encodedUri = URLEncoder.encode(uri.toString(), StandardCharsets.UTF_8.toString())
                                    val encodedName = URLEncoder.encode(name, StandardCharsets.UTF_8.toString())
                                    navController.navigate("language_select/$type/$encodedName/$encodedUri")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("audio_upload") {
                            AudioUploadScreen(
                                viewModel = viewModel,
                                onNavigateNext = { type, name, uri ->
                                    val encodedUri = URLEncoder.encode(uri.toString(), StandardCharsets.UTF_8.toString())
                                    val encodedName = URLEncoder.encode(name, StandardCharsets.UTF_8.toString())
                                    navController.navigate("language_select/$type/$encodedName/$encodedUri")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("youtube_upload") {
                            YoutubeUrlScreen(
                                viewModel = viewModel,
                                onNavigateNext = { type, name, url ->
                                    val encodedUrl = URLEncoder.encode(url, StandardCharsets.UTF_8.toString())
                                    val encodedName = URLEncoder.encode(name, StandardCharsets.UTF_8.toString())
                                    navController.navigate("language_select/$type/$encodedName/$encodedUrl")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(
                            route = "language_select/{type}/{name}/{value}",
                            arguments = listOf(
                                navArgument("type") { type = NavType.StringType },
                                navArgument("name") { type = NavType.StringType },
                                navArgument("value") { type = NavType.StringType }
                            )
                        ) { backStackEntry ->
                            val type = backStackEntry.arguments?.getString("type") ?: "file"
                            val name = URLDecoder.decode(backStackEntry.arguments?.getString("name") ?: "", StandardCharsets.UTF_8.toString())
                            val value = URLDecoder.decode(backStackEntry.arguments?.getString("value") ?: "", StandardCharsets.UTF_8.toString())

                            LanguageScreen(
                                viewModel = viewModel,
                                sourceType = type,
                                sourceName = name,
                                sourceValue = value,
                                onStartTranscribing = { sourceType, sourceName, language, modelName, uri, ytUrl ->
                                    viewModel.transcribeSource(
                                        context = applicationContext,
                                        sourceType = sourceType,
                                        sourceName = sourceName,
                                        language = language,
                                        modelName = modelName,
                                        uri = uri,
                                        youtubeUrl = ytUrl
                                    )
                                    navController.navigate("processing") {
                                        popUpTo("home")
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("processing") {
                            val state = uiState
                            val progressText = if (state is UiState.Loading) state.progressText else "Processing transcription with Gemini AI..."
                            LoadingScreen(progressText = progressText)
                        }
                        composable("results") {
                            val state = uiState
                            if (state is UiState.Success) {
                                ResultScreen(
                                    result = state.result,
                                    viewModel = viewModel,
                                    onEdit = { navController.navigate("editor") },
                                    onBack = {
                                        viewModel.resetState()
                                        navController.popBackStack("home", inclusive = false)
                                    }
                                )
                            }
                        }
                        composable("editor") {
                            val state = uiState
                            if (state is UiState.Success) {
                                EditorScreen(
                                    result = state.result,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }
                        composable("history") {
                            HistoryScreen(
                                viewModel = viewModel,
                                onSelectTranscript = { _ ->
                                    navController.navigate("results")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(onBack = { navController.popBackStack() })
                        }
                        composable("about") {
                            AboutScreen(onBack = { navController.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}
